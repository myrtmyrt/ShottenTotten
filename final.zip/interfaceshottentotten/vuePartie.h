#ifndef VUEPARTIE_H
#define VUEPARTIE_H

#include "vueParametres.h"
#include "vuecarte.h"
#include "vueBorne.h"
#include <vector>
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QRadioButton>
#include <QButtonGroup>
#include <QVBoxLayout>
#include <QSizePolicy>
#include "jeu.h"
#include "carte.h"
#include "manche.h"

Mode convertQStringToMode(const QString& modeString);

class VuePartie : public QMainWindow
{
    Q_OBJECT

public:
    VuePartie(QWidget *parent = nullptr, Parametres p = Parametres{}) : QMainWindow(parent), param(p) {
        QWidget *mainWidget = new QWidget(this);
        setCentralWidget(mainWidget);

        Mode enumMode = convertQStringToMode(param.mode);
        Jeu jeu = Jeu::donneInstance(param.joueur1.toStdString(), param.joueur2IA, param.joueur2.toStdString(), enumMode, param.rounds);
        mancheActuelle = new Manche(jeu);

        vLayoutLeft = new QVBoxLayout(mainWidget);
        hLayoutTop = new QHBoxLayout;
        hLayoutMiddle = new QHBoxLayout;
        hLayoutBottom = new QHBoxLayout;

        for (size_t i = 0; i < jeu.getJoueur2().getCartes().size(); i++) {
            Carte* carte = jeu.getJoueur2().getCartes()[i];
            VueCarte* vueCarte = new VueCarte(*carte, this);
            vuecartesPlayer2.push_back(vueCarte);
            hLayoutTop->addWidget(vueCarte);

            connect(vueCarte, SIGNAL(cardClicked(VueCarte*)), this, SLOT(onCardClicked(VueCarte*)));
        }
        hLayoutTop->setAlignment(Qt::AlignTop | Qt::AlignCenter);

        for (size_t i = 0; i < mancheActuelle->getBornes().size(); i++) {
            QVBoxLayout *borneLayout = new QVBoxLayout();
            borneLayouts.push_back(borneLayout);

            Borne* borne = mancheActuelle->getBornes()[i];

            // Create VueCarte widget for the top position
            std::vector<VueCarte*> vueCartesJ2;
            if (borne->getCartesJoueur2().size() > 0) {
                for (size_t j = 0; j < borne->getCartesJoueur2().size(); j++) {
                    VueCarte* vueCarteTop = new VueCarte(*borne->getCartesJoueur2()[j], mainWidget);
                    vueCartesJ2.push_back(vueCarteTop);
                    borneLayouts[i]->addWidget(vueCarteTop);
                }
            }
            vuecartesBornesPlayer2.push_back(vueCartesJ2);


            VueBorne* vueBorne = new VueBorne(*borne, this);
            vuebornes.push_back(vueBorne);
            borneLayouts[i]->addWidget(vueBorne);

            connect(vueBorne, SIGNAL(borneClicked(VueBorne*)), this, SLOT(onBorneClicked(VueBorne*)));

            std::vector<VueCarte*> vueCartesJ1;
            if (borne->getCartesJoueur1().size() > 0) {
                for (size_t j = 0; j < borne->getCartesJoueur1().size(); j++) {
                    VueCarte* vueCarteBottom = new VueCarte(*borne->getCartesJoueur1()[j], mainWidget);
                    vueCartesJ1.push_back(vueCarteBottom);
                    borneLayouts[i]->addWidget(vueCarteBottom);
                }
            }
            vuecartesBornesPlayer1.push_back(vueCartesJ1);

            hLayoutMiddle->addLayout(borneLayout);
        }
        hLayoutMiddle->setAlignment(Qt::AlignCenter);

        for (size_t i = 0; i < jeu.getJoueur1().getCartes().size(); i++) {
            Carte* carte = jeu.getJoueur1().getCartes()[i];
            VueCarte* vueCarte = new VueCarte(*carte, this);
            vuecartesPlayer1.push_back(vueCarte);
            hLayoutBottom->addWidget(vueCarte);

            connect(vueCarte, SIGNAL(cardClicked(VueCarte*)), this, SLOT(onCardClicked(VueCarte*)));
        }
        hLayoutBottom->setAlignment(Qt::AlignBottom | Qt::AlignCenter);


        updateVueCardsJoueur(1);
        updateVueBornes();

        vLayoutLeft->addLayout(hLayoutTop);
        vLayoutLeft->addLayout(hLayoutMiddle);
        vLayoutLeft->addLayout(hLayoutBottom);

        startTour();

    }

private slots:
    void onCardClicked(VueCarte* carte) {
        // Handle card clicked event
        if(tour == 1){
            if(carteSelected != nullptr){
                for (size_t i = 0; i < vuecartesPlayer1.size(); i++) {
                    vuecartesPlayer1[i]->setChecked(false);
                }
                carteSelected = carte;
                carte->setChecked(true);
            }else{
                carteSelected = carte;
            }
        }else{
            if(carteSelected != nullptr){
                for (size_t i = 0; i < vuecartesPlayer2.size(); i++) {
                    vuecartesPlayer2[i]->setChecked(false);
                }
                carteSelected = carte;
                carte->setChecked(true);
            }else{
                carteSelected = carte;
            }
        }
    }

    void onBorneClicked(VueBorne* borne) {
        Jeu jeu = Jeu::getInstance();
        if(borne->getBorne()->getGagnant() == nullptr && (tour == 1 && !borne->getBorne()->estPleine(jeu.getJoueur1())) || (tour == 2 && !borne->getBorne()->estPleine(jeu.getJoueur2()))){
        if (carteSelected != nullptr) {
            // Handle borne clicked event
            if (borneSelected != nullptr) {
                for (size_t i = 0; i < vuebornes.size(); i++) {
                    vuebornes[i]->setChecked(false);
                }
                borneSelected = borne;
                borne->setChecked(true);
            } else {
                borneSelected = borne;
            }
            if(tour == 1){
                Carte* carteToPush = carteSelected->getCarte();

                mancheActuelle->getBornes()[borneSelected->getBorne()->getNumero()]->poserCarte(&jeu.getJoueur1(), carteToPush);
                mancheActuelle->getPioche().piocher("Clan", jeu.getJoueur1());
                mancheActuelle->getBornes()[borneSelected->getBorne()->getNumero()]->revendiquer(borneSelected->getBorne()->getNumero(), jeu.getJoueur1(), jeu.getJoueur2(), mancheActuelle, &mancheActuelle->getPioche());
                if(mancheActuelle->getBornes()[borneSelected->getBorne()->getNumero()]->getGagnant() != nullptr){
                    showWarning(mancheActuelle->getBornes()[borneSelected->getBorne()->getNumero()]->getGagnant()->getPseudo()+" a gagné la borne.");
                }
            }else{
                Carte* carteToPush = carteSelected->getCarte();
                mancheActuelle->getBornes()[borneSelected->getBorne()->getNumero()]->poserCarte(&jeu.getJoueur2(), carteToPush);
                mancheActuelle->getPioche().piocher("Clan", jeu.getJoueur2());
                mancheActuelle->getBornes()[borneSelected->getBorne()->getNumero()]->revendiquer(borneSelected->getBorne()->getNumero(), jeu.getJoueur2(), jeu.getJoueur1(), mancheActuelle, &mancheActuelle->getPioche());
                if(mancheActuelle->getBornes()[borneSelected->getBorne()->getNumero()]->getGagnant() != nullptr){
                    showWarning(mancheActuelle->getBornes()[borneSelected->getBorne()->getNumero()]->getGagnant()->getPseudo()+" a gagné la borne.");
                }
            }

            for (Borne* borne : mancheActuelle->getBornes()) {
                bool isGagnant = mancheActuelle->verifGagnant(jeu.getJoueur1());
                if (isGagnant == true) {
                    showWarning("Gagnant de la manche : "+jeu.getJoueur1().getPseudo());
                    jeu.getJoueur1().addPoint();
                    close();
                    return;
                }
                isGagnant = mancheActuelle->verifGagnant(jeu.getJoueur2());
                if (isGagnant == true) {
                    showWarning("Gagnant de la manche : "+jeu.getJoueur2().getPseudo());
                    jeu.getJoueur2().addPoint();
                    close();
                    return;
                }

            }

            updateVueBornes();
            updateVueCardsJoueur(1);
            updateVueCardsJoueur(2);

            carteSelected = nullptr;
            borneSelected = nullptr;

            startTour();

        } else {
            for (size_t i = 0; i < vuebornes.size(); i++) {
                vuebornes[i]->setChecked(false);
            }
            showWarning("Vous devez choisir une carte à jouer avant de choisir une borne.");
        }
        }else{
            showWarning("Vous ne devez pas choisir une borne gagnée ou pleine.");
        }
    }

private:
    Parametres param;
    QVBoxLayout* vLayoutLeft;
    QHBoxLayout* hLayoutTop;
    QHBoxLayout* hLayoutMiddle;
    QHBoxLayout* hLayoutBottom;
    std::vector<QVBoxLayout*> borneLayouts;
    std::vector<VueCarte*> vuecartesPlayer1;
    std::vector<VueCarte*> vuecartesPlayer2;
    std::vector<VueBorne*> vuebornes;
    std::vector<std::vector<VueCarte*>> vuecartesBornesPlayer1;
    std::vector<std::vector<VueCarte*>> vuecartesBornesPlayer2;
    Manche* mancheActuelle = nullptr;
    VueCarte* carteSelected = nullptr;
    VueBorne* borneSelected = nullptr;
    unsigned int tour = 2;
    bool userFinishedTour = false;
    bool userWon = false;

    void updateVueCardsJoueur(unsigned int numero);
    void updateVueBornes();
    bool startTour();
    void showWarning(std::string message);
};

#endif // VUEPARTIE_H
