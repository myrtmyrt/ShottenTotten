#include "vuecarte.h"
#include <QString>
#include <QPalette>
#include <QStaticText>
VueCarte::VueCarte(Carte& c, QWidget *parent) : QPushButton(parent),carte(&c)
{
    QString styleSheet;
    if(c.getCouleur() == Couleur::bleu){
        styleSheet = "background-color: blue; font-size:40pt; font-weight:bold;";
    }else if(c.getCouleur() == Couleur::jaune){
        styleSheet = "background-color: yellow; font-size:40pt; font-weight:bold;";
    }else if(c.getCouleur() == Couleur::orange){
        styleSheet = "background-color: orange; font-size:40pt; font-weight:bold;";
    }else if(c.getCouleur() == Couleur::rouge){
        styleSheet = "background-color: red; font-size:40pt; font-weight:bold;";
    }else if(c.getCouleur() == Couleur::vert){
        styleSheet = "background-color: green; font-size:40pt; font-weight:bold;";
    }else if(c.getCouleur() == Couleur::violet){
        styleSheet = "background-color: violet; font-size:40pt; font-weight:bold;";
    }
    QString nombre = QString::fromStdString(toString(c.getNombre()));
    setText(nombre);
    setStyleSheet(styleSheet);
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);
    setFixedSize(50,100);
    connect(this,SIGNAL(clicked()),this,SLOT(clickedEvent()));
    setCheckable(true);
}

VueCarte::VueCarte(QWidget *parent): QPushButton(parent)
{
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);
    setFixedSize(120,200);
    connect(this,SIGNAL(clicked()),this,SLOT(clickedEvent()));
    setCheckable(false);
}

