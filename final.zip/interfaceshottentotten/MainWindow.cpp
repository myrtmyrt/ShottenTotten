#include "MainWindow.h"
#include "utils.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    button = new QPushButton("Click Me", this);
    connect(button, &QPushButton::clicked, this, &MainWindow::onButtonClicked);

    label = new QLabel("Initial Text", this);

    setCentralWidget(label);
}

void MainWindow::onButtonClicked()
{
//    QString data = Utils::getData(); // Utilisation de la fonction utilitaire
//    label->setText(data);
}
