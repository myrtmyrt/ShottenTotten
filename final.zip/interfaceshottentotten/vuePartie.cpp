#include "vuePartie.h"
#include "jeu.h"
#include <QVBoxLayout>
#include <QMessageBox>


Mode convertQStringToMode(const QString& modeString)
{
    if (modeString == "normal")
    {
        return Mode::normal;
    }
    else if (modeString == "tactique")
    {
        return Mode::tactique;
    }
    else if (modeString == "expert")
    {
        return Mode::expert;
    }

    // Valeur par défaut en cas d'erreur ou de couleur non reconnue
    return Mode::normal;
}

void VuePartie::updateVueCardsJoueur(unsigned int numero){
    if(numero == 1){
        for (auto* vueCarte : vuecartesPlayer1) {
            hLayoutBottom->removeWidget(vueCarte);
            vueCarte->hide();
            delete vueCarte;
        }
        vuecartesPlayer1.clear();

        Jeu* jeuActuel = &Jeu::getInstance();

        for (size_t i = 0; i < jeuActuel->getJoueur1().getCartes().size(); i++) {
            Carte* carte= jeuActuel->getJoueur1().getCartes()[i];
            vuecartesPlayer1.push_back(new VueCarte(*carte, this));
            hLayoutBottom->addWidget(vuecartesPlayer1[i]);

            connect(vuecartesPlayer1[i], SIGNAL(cardClicked(VueCarte*)), this, SLOT(onCardClicked(VueCarte*)));
        }
    }else{
        Jeu* jeuActuel = &Jeu::getInstance();

        for (auto* vueCarte : vuecartesPlayer2) {
            hLayoutTop->removeWidget(vueCarte);
            vueCarte->hide();
            delete vueCarte;
        }
        vuecartesPlayer2.clear();
        for (size_t i = 0; i < jeuActuel->getJoueur2().getCartes().size(); i++) {
            Carte* carte= jeuActuel->getJoueur2().getCartes()[i];
            vuecartesPlayer2.push_back(new VueCarte(*carte, this));
            hLayoutTop->addWidget(vuecartesPlayer2[i]);

            connect(vuecartesPlayer2[i], SIGNAL(cardClicked(VueCarte*)), this, SLOT(onCardClicked(VueCarte*)));
        }
    }


}

void VuePartie::updateVueBornes() {
    for (size_t i = 0; i < mancheActuelle->getBornes().size(); i++) {
        // Clear vuecartesBornesPlayer1 for each iteration
        for (auto* vueCarte : vuecartesBornesPlayer1[i]) {
            borneLayouts[i]->removeWidget(vueCarte);
            vueCarte->hide();
            delete vueCarte;
        }
        vuecartesBornesPlayer1[i].clear();
        // Clear vuecartesBornesPlayer2 for each iteration
        for (auto* vueCarte : vuecartesBornesPlayer2[i]) {
            borneLayouts[i]->removeWidget(vueCarte);
            vueCarte->hide();
            delete vueCarte;
        }
        vuecartesBornesPlayer2[i].clear();

        borneLayouts[i]->removeWidget(vuebornes[i]);
        vuebornes[i]->hide();
        delete vuebornes[i];
    }

    vuecartesBornesPlayer1.clear();
    vuecartesBornesPlayer2.clear();
    vuebornes.clear();

    for (size_t i = 0; i < mancheActuelle->getBornes().size(); i++) {
        Borne* borne = mancheActuelle->getBornes()[i];

        std::vector<VueCarte*> vueCartesJ2;
        for (size_t j = 0; j < borne->getCartesJoueur2().size(); j++) {
            VueCarte* vueCarteTop = new VueCarte(*borne->getCartesJoueur2()[j]);
            vueCartesJ2.push_back(vueCarteTop);
            borneLayouts[i]->addWidget(vueCarteTop);
        }
        vuecartesBornesPlayer2.push_back(vueCartesJ2);

        VueBorne* vueBorne = new VueBorne(*borne, this);
        if(borne->getGagnant() != nullptr){
            vueBorne->setCheckable(false);
            if(borne->getGagnant()->getId() == 1){
                vueBorne->setStyleSheet("font-size:30pt; font-weight:bold; background-color: blue;");
            }else{
                vueBorne->setStyleSheet("font-size:30pt; font-weight:bold; background-color: red;");
            }
        }
        vuebornes.push_back(vueBorne);
        borneLayouts[i]->addWidget(vueBorne);
        connect(vueBorne, SIGNAL(borneClicked(VueBorne*)), this, SLOT(onBorneClicked(VueBorne*)));

        std::vector<VueCarte*> vueCartesJ1;
        for (size_t j = 0; j < borne->getCartesJoueur1().size(); j++) {
            VueCarte* vueCarteBottom = new VueCarte(*borne->getCartesJoueur1()[j]);
            vueCartesJ1.push_back(vueCarteBottom);
            borneLayouts[i]->addWidget(vueCarteBottom);
        }
        vuecartesBornesPlayer1.push_back(vueCartesJ1);
    }
}

bool VuePartie::startTour(){
    if(tour == 1){
        tour = 2;

    }else{
        tour = 1;
    }

    Jeu* jeuActuel = &Jeu::getInstance();
    if(tour == 1){
        for (auto* vueCarte : vuecartesPlayer2) {
            vueCarte->hide();
        }
        for (auto* vueCarte : vuecartesPlayer1) {
            vueCarte->hide();
        }
        showWarning("Tour de "+jeuActuel->getJoueur1().getPseudo());
        for (auto* vueCarte : vuecartesPlayer1) {
            vueCarte->show();
        }

    }else{

        for (auto* vueCarte : vuecartesPlayer1) {
            vueCarte->hide();
        }
        for (auto* vueCarte : vuecartesPlayer2) {
            vueCarte->hide();
        }
        showWarning("Tour de "+jeuActuel->getJoueur2().getPseudo());
        for (auto* vueCarte : vuecartesPlayer2) {
            vueCarte->show();
        }
    }
}

void VuePartie::showWarning(std::string message) {
    const char* messageNew = message.c_str();;
    QMessageBox messageBox(QMessageBox::Icon::Warning, "Attention", messageNew);
    messageBox.exec();
}

