#ifndef BORNE
#define BORNE

#include <iostream>
#include <string>
#include <algorithm>

#include "carte.h"
#include "joueur.h"
#include "pioche.h"
#include "utils.h"

class VuePartie;
class Manche;

int toInt(Nombre n);

class Borne {
private:
    size_t _numero;
    size_t _nbCartesMax;
    std::vector<Carte*> _cartesJoueur1;
    std::vector<Carte*> _cartesJoueur2;
    Joueur* _gagnant;
public:
    //GETTERS
    std::vector<Carte*> getCartesJoueur1() const { return _cartesJoueur1; }
    std::vector<Carte*> getCartesJoueur2() const { return _cartesJoueur2; }
    Joueur* getGagnant() const { return _gagnant; }
    size_t getNumero() const {return _numero;}

    //SETTERS
    void setGagnant(Joueur* j) { _gagnant = j; }
    void setNbCartesMax(unsigned int t){_nbCartesMax=t;}

    //Contructeur, destructeur, recopie par défaut
    Borne(size_t numero) : _gagnant(nullptr), _nbCartesMax(3), _numero(numero){}
    ~Borne() { delete _gagnant; }
    //ICI CONSTRUCTEUR RECOPIE...


    //Ajouter/Retirer une carte
    void poserCarte(Joueur* j, Carte* c);
    void changerCarte(Joueur& j, Carte* c);
    void retirerCarte(Joueur& j, Carte* c);

    //Afficher une borne
    void afficher() const;
    void afficherCartesJ1() const;
    void afficherCartesJ2() const;
    //void revendiquerBorne();

    bool estPleine(Joueur &j) const;

    unsigned int trouverGagnant(unsigned int idPremier, Joueur& j1, Joueur& j2, Manche* manche);
    unsigned int calculerPoints(std::vector<Carte*> _cartesJoueur, Joueur& j);
    bool revendiquer(unsigned int idBorne, Joueur& jrevendique, Joueur& jsecond, Manche* manche, Pioche* pioche);
    bool trouverGagnantCartes(unsigned int idPremier, Joueur& jrevendique, Joueur& jsecond, std::vector<Carte *> cartesJoueurRevendique, std::vector<Carte *> cartesJoueurAutre, Manche* manche);

};


#endif //BORNE
