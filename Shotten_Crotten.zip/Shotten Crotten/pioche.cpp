#include "pioche.h"

Pioche::Pioche(std::vector<Carte*> cartes) {
    _cartes = cartes;
}

void Pioche::piocher(std::string type, Joueur &jou) {
    int carteNum = 0;
    std::vector<Carte*> cartesTypes;
    for (Carte* card : _cartes) {
        if (card->getType() == type) {
            carteNum++;
            cartesTypes.push_back(card);
        }
    }
    if(carteNum == 0){
        return;
    }
    srand(time(NULL)*200);
    size_t random = rand() % cartesTypes.size();

    Carte* carte = cartesTypes[random];

    size_t j = 0;
    for (j = 0; j < _cartes.size(); ++j) {
        if (_cartes[j] == carte) {
            break;
        }
    }

    _cartes.erase(_cartes.begin()+j);

    jou.addCarte(carte);

}
