#include <QApplication>
#include "vueParametres.h"
#include "vuePartie.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // Création de la fenêtre de paramètres
    VueParametres vueParametres;
    vueParametres.show();

    // Exécution de la boucle d'événements pour la fenêtre de paramètres
    return app.exec();

    // Récupération des paramètres de jeu à partir de la fenêtre de paramètres
    Parametres parametres = vueParametres.getParametres();

    // Création de la fenêtre de partie en utilisant les paramètres
    VuePartie vuePartie(&vueParametres, parametres);
    vuePartie.show();

    // Exécution de la boucle d'événements pour la fenêtre de partie
    return app.exec();
}
