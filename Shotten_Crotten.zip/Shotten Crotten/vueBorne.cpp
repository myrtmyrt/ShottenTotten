#include "vueBorne.h"
#include <QString>
#include <QPalette>
#include <QStaticText>
VueBorne::VueBorne(Borne& b, QWidget *parent) : QPushButton(parent),borne(&b)
{
    QString nombre = QString::number(b.getNumero()+1);
    QString styleSheet;
    styleSheet = "font-size:30pt; font-weight:bold;";
    setStyleSheet(styleSheet);
    setText(nombre);
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);
    setFixedSize(100,50);
    connect(this,SIGNAL(clicked()),this,SLOT(clickedEvent()));
    setCheckable(true);
}



