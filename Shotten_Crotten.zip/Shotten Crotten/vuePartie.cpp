#include "vuePartie.h"
#include "jeu.h"
#include <QVBoxLayout>
#include <QMessageBox>


Mode convertQStringToMode(const QString& modeString)
{
    if (modeString == "normal")
    {
        return Mode::normal;
    }
    else if (modeString == "tactique")
    {
        return Mode::tactique;
    }
    else if (modeString == "expert")
    {
        return Mode::expert;
    }

    // Valeur par défaut en cas d'erreur ou de couleur non reconnue
    return Mode::normal;
}

void VuePartie::updateVueCardsJoueur(unsigned int numero){
    if(numero == 1){
        for (auto* vueCarte : vuecartesPlayer1) {
            hLayoutBottom->removeWidget(vueCarte);
            vueCarte->hide();
            delete vueCarte;
        }
        vuecartesPlayer1.clear();

        Jeu* jeuActuel = &Jeu::getInstance();

        for (size_t i = 0; i < jeuActuel->getJoueur1().getCartes().size(); i++) {
            Carte* carte= jeuActuel->getJoueur1().getCartes()[i];
            vuecartesPlayer1.push_back(new VueCarte(*carte, this));
            hLayoutBottom->addWidget(vuecartesPlayer1[i]);

            connect(vuecartesPlayer1[i], SIGNAL(cardClicked(VueCarte*)), this, SLOT(onCardClicked(VueCarte*)));
        }
    }else{
        Jeu* jeuActuel = &Jeu::getInstance();

        for (auto* vueCarte : vuecartesPlayer2) {
            hLayoutTop->removeWidget(vueCarte);
            vueCarte->hide();
            delete vueCarte;
        }
        vuecartesPlayer2.clear();
        for (size_t i = 0; i < jeuActuel->getJoueur2().getCartes().size(); i++) {
            Carte* carte= jeuActuel->getJoueur2().getCartes()[i];
            vuecartesPlayer2.push_back(new VueCarte(*carte, this));
            hLayoutTop->addWidget(vuecartesPlayer2[i]);

            connect(vuecartesPlayer2[i], SIGNAL(cardClicked(VueCarte*)), this, SLOT(onCardClicked(VueCarte*)));
        }
    }


}

void VuePartie::updateVueBornes() {
    for (size_t i = 0; i < mancheActuelle->getBornes().size(); i++) {
        // Clear vuecartesBornesPlayer1 for each iteration
        for (auto* vueCarte : vuecartesBornesPlayer1[i]) {
            gridLayoutMiddle->removeWidget(vueCarte);
            vueCarte->hide();
            delete vueCarte;
        }
        vuecartesBornesPlayer1[i].clear();
        // Clear vuecartesBornesPlayer2 for each iteration
        for (auto* vueCarte : vuecartesBornesPlayer2[i]) {
            gridLayoutMiddle->removeWidget(vueCarte);
            vueCarte->hide();
            delete vueCarte;
        }
        vuecartesBornesPlayer2[i].clear();

        gridLayoutMiddle->removeWidget(vuebornes[i]);
        vuebornes[i]->hide();
        delete vuebornes[i];
    }

    vuecartesBornesPlayer1.clear();
    vuecartesBornesPlayer2.clear();
    vuebornes.clear();

    for (size_t i = 0; i < mancheActuelle->getBornes().size(); i++) {
        Borne* borne = mancheActuelle->getBornes()[i];
        int gridLayout = 2;
        std::vector<VueCarte*> vueCartesJ2;
        for (size_t j = 0; j < borne->getCartesJoueur2().size(); j++) {
            VueCarte* vueCarteTop = new VueCarte(*borne->getCartesJoueur2()[j]);
            vueCartesJ2.push_back(vueCarteTop);
            gridLayoutMiddle->addWidget(vueCarteTop, gridLayout, i);
            gridLayout--;
        }
        vuecartesBornesPlayer2.push_back(vueCartesJ2);

        VueBorne* vueBorne = new VueBorne(*borne, this);
        if (borne->getGagnant() != nullptr) {
            vueBorne->setCheckable(false);
            if (borne->getGagnant()->getId() == 1) {
                vueBorne->setStyleSheet("font-size:30pt; font-weight:bold; background-color: pink;");
            } else {
                vueBorne->setStyleSheet("font-size:30pt; font-weight:bold; background-color: brown;");
            }
        }
        vuebornes.push_back(vueBorne);
        gridLayoutMiddle->addWidget(vueBorne, 3, i);
        connect(vueBorne, SIGNAL(borneClicked(VueBorne*)), this, SLOT(onBorneClicked(VueBorne*)));

        gridLayout = 4;
        std::vector<VueCarte*> vueCartesJ1;
        for (size_t j = 0; j < borne->getCartesJoueur1().size(); j++) {
            VueCarte* vueCarteBottom = new VueCarte(*borne->getCartesJoueur1()[j]);
            vueCartesJ1.push_back(vueCarteBottom);
            gridLayoutMiddle->addWidget(vueCarteBottom, gridLayout, i);
            gridLayout++;
        }
        vuecartesBornesPlayer1.push_back(vueCartesJ1);
    }
}

bool VuePartie::startTour(){
    if(tour == 1){
        tour = 2;

    }else{
        tour = 1;
    }

    Jeu* jeuActuel = &Jeu::getInstance();
    if(tour == 1){
        for (auto* vueCarte : vuecartesPlayer2) {
            vueCarte->hide();
        }
        for (auto* vueCarte : vuecartesPlayer1) {
            vueCarte->hide();
        }
        if(jeuActuel->getJoueur1().getIsBot() == false){
            showWarning("Tour de "+jeuActuel->getJoueur1().getPseudo());
        }
        if(jeuActuel->getJoueur1().getIsBot() == false || (jeuActuel->getJoueur2().getIsBot() == true && jeuActuel->getJoueur1().getIsBot() == true) ){
            for (auto* vueCarte : vuecartesPlayer1) {
                vueCarte->show();
            }
        }
        if(jeuActuel->getJoueur1().getIsBot() == true){
            unsigned int carteToPlay = jeuActuel->getJoueur1().jouerCarteIA();
            carteSelected = vuecartesPlayer1[carteToPlay-1];

            bool isPlayable = false;
            while(isPlayable == false){
                unsigned int borneToPlay = jeuActuel->getJoueur1().jouerBorneIA(*mancheActuelle);
                if(vuebornes[borneToPlay-1]->getBorne()->estPleine(jeuActuel->getJoueur1()) || vuebornes[borneToPlay-1]->getBorne()->getGagnant() != nullptr){
                    isPlayable = false;
                }else{
                    isPlayable = true;
                    onBorneClicked(vuebornes[borneToPlay-1]);

                }
            }
        }
    }else{

        for (auto* vueCarte : vuecartesPlayer1) {
            vueCarte->hide();
        }
        for (auto* vueCarte : vuecartesPlayer2) {
            vueCarte->hide();
        }
        if(jeuActuel->getJoueur2().getIsBot() == false){
            showWarning("Tour de "+jeuActuel->getJoueur2().getPseudo());
        }
        if(jeuActuel->getJoueur2().getIsBot() == false || (jeuActuel->getJoueur2().getIsBot() == true && jeuActuel->getJoueur1().getIsBot() == true) ){
            for (auto* vueCarte : vuecartesPlayer2) {
                vueCarte->show();
            }
        }
        if(jeuActuel->getJoueur2().getIsBot() == true){
            unsigned int carteToPlay = jeuActuel->getJoueur2().jouerCarteIA();
            carteSelected = vuecartesPlayer2[carteToPlay-1];

            bool isPlayable = false;
            while(isPlayable == false){
                unsigned int borneToPlay = jeuActuel->getJoueur2().jouerBorneIA(*mancheActuelle);
                if(vuebornes[borneToPlay-1]->getBorne()->estPleine(jeuActuel->getJoueur2()) || vuebornes[borneToPlay-1]->getBorne()->getGagnant() != nullptr){
                    isPlayable = false;
                }else{
                    isPlayable = true;
                    onBorneClicked(vuebornes[borneToPlay-1]);

                }
            }
        }
    }
}

void VuePartie::showWarning(std::string message) {
    const char* messageNew = message.c_str();;
    QMessageBox messageBox(QMessageBox::Icon::Warning, "Attention", messageNew);
    messageBox.exec();
}

