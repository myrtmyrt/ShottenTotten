#ifndef VUECARTE_H
#define VUECARTE_H

#include <QWidget>
#include <QPushButton>
#include "carte.h"

class VueCarte : public QPushButton
{
    Q_OBJECT
public:
    VueCarte(Carte& c, QWidget *parent = nullptr);
    explicit VueCarte(QWidget *parent = nullptr);
    // affecter une nouvelle carte à la vue
    void setCarte(const Carte& c);
    // vue sans carte
    void setNoCarte();
    Carte* getCarte() const {return carte;};
    bool cartePresente() const;
signals:
    void cardClicked(VueCarte*);
public slots:
private slots:
    void clickedEvent() { emit cardClicked(this); }

private:
    Carte* carte=nullptr;
};

#endif // VUECARTE_H
