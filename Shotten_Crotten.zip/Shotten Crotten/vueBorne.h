#ifndef VUEBORNE_H
#define VUEBORNE_H

#include <QWidget>
#include <QPushButton>
#include "vuecarte.h"
#include "borne.h"
#include "carte.h"

class VueBorne : public QPushButton
{
    Q_OBJECT
public:
    VueBorne(Borne& b, QWidget *parent = nullptr);
    //explicit VueBorne(QWidget *parent = nullptr);
    //void afficherBorne();
    Borne* getBorne() const {return borne;};

signals:
    void borneClicked(VueBorne*);
public slots:
private slots:
    void clickedEvent() { emit borneClicked(this); }

private:
    Borne* borne=nullptr;
    std::vector<VueCarte*> vuecartesPlayer1;
    std::vector<VueCarte*> vuecartesPlayer2;
};

#endif // VUEBORNE_H
