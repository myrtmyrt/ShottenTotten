#include "manche.h"
#include "carte.h"

#define BORNES 9

std::initializer_list<Couleur> Couleurs = { Couleur::rouge, Couleur::bleu, Couleur::vert, Couleur::violet, Couleur::orange, Couleur::jaune };
std::initializer_list<Nombre> Nombres = { Nombre::un, Nombre::deux, Nombre::trois, Nombre::quatre, Nombre::cinq, Nombre::six, Nombre::sept, Nombre::huit, Nombre::neuf };

//std::unordered_map<TypeTactique, std::pair<jouerFonction, effetFonction>> TypeTactiques = {
//    { TypeTactique::joker, { Tactique::jouerJoker, Tactique::effetJoker } },
//    { TypeTactique::joker, { Tactique::jouerJoker, Tactique::effetJoker } },
//    { TypeTactique::espion, { Tactique::jouerEspion, Tactique::effetEspion } },
//    { TypeTactique::porteBouclier, { Tactique::jouerPorteBouclier, Tactique::effetPorteBouclier } },
//    { TypeTactique::colinMaillard, { Tactique::jouerColinMaillard, Tactique::effetColinMaillard } },
//    { TypeTactique::combatBoue, { Tactique::jouerCombatBoue, Tactique::effetCombatBoue } },
//    { TypeTactique::chasseurTete, { Tactique::jouerChasseurTete, Tactique::effetChasseurTete } },
//    { TypeTactique::stratege, { Tactique::jouerStratege, Tactique::effetStratege } },
//    { TypeTactique::banshee, { Tactique::jouerBanshee, Tactique::effetBanshee } },
//    { TypeTactique::traitre, { Tactique::jouerTraitre, Tactique::effetTraitre } }
//};


Manche::Manche(Jeu &jeu) {

    /*
     * CRÉATION DES BORNES
     */
    std::vector<Borne*> bornes;
    for (size_t i = 0; i < BORNES; ++i) bornes.push_back(new Borne(i));
    _bornes = bornes;


    /*
     * CRÉATION DES CARTES CLAN ET TACTIQUES
     */
    Mode modeDeJeu = jeu.getModeDeJeu();
    std::vector<Carte*> cartes;

    for (auto c : Couleurs) {
        for (auto n: Nombres) {
            cartes.push_back(new Clan(n, c));
        }
    }

//    if(modeDeJeu == Mode::tactique) {
//        for (auto t: TypeTactiques) {
//            cartes.push_back(new Tactique(t.first, t.second.first, t.second.second));
//        }
//    }

    _cartes = cartes;

    /*
     * CRÉATION DE LA PIOCHE À PARTIR DES CARTES
     */
    _pioche = new Pioche(cartes);


    /*
     * DISTRIBUTION DES CARTES AUX JOUEURS EN FONCTION DU TYPE
     */
    for (size_t j = 0; j < 7; ++j) {
        if(j == 6){
            if(modeDeJeu == Mode::tactique) {
                _pioche->piocher("Clan", jeu.getJoueur1());
                _pioche->piocher("Clan", jeu.getJoueur2());
            }
        }else{
            _pioche->piocher("Clan", jeu.getJoueur1());
            _pioche->piocher("Clan", jeu.getJoueur2());
        }
    }

}

void Manche::afficherBornes() const {
    for (Borne* borne : _bornes) {
        borne->afficher();
    }
}

bool Manche::verifGagnant(Joueur& jou) const {
    unsigned int bornesWinNum = 0;

    bool borneWin[_bornes.size()];

    int i=0;
    for (Borne* borne : _bornes) {
        if (borne->getGagnant() != nullptr) {
            if (borne->getGagnant()->getId() == jou.getId()) {
                borneWin[i++] = true;
                bornesWinNum++;
            } else {
                borneWin[i++] = false;
            }
        }else{
            borneWin[i++] = false;
        }

    }

    if (bornesWinNum >= 5) {
        return true;
    }

    unsigned int consecutiveWin = 0;
    unsigned int consecutiveWinMax = 0;
    for (int j = 0; j < _bornes.size(); ++j) {
        if(borneWin[j] == true){
            consecutiveWin++;
            if(consecutiveWinMax < consecutiveWin){
                consecutiveWinMax = consecutiveWin;
            }
        }else{
            consecutiveWin = 0;
        }
    }

    if(consecutiveWinMax >= 3){
        return true;
    }

    return false;
}
