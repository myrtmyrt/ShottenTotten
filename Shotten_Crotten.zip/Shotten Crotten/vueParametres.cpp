#include "vueParametres.h"
#include "vuePartie.h"
#include <QVBoxLayout>

Parametres VueParametres::getParametres() const {
    Parametres parametres;
    parametres.joueur1 = player1LineEdit->text();
    parametres.joueur2 = player2LineEdit->text();
    parametres.mode = modeComboBox->currentText();
    parametres.rounds = roundsLineEdit->text().toInt();
    parametres.joueur1IA = player2IARadio->isChecked();
    parametres.joueur2IA = allplayersIARadio->isChecked();
    return parametres;
}

VueParametres::VueParametres(QWidget *parent): QMainWindow(parent)
{
    player1Label = new QLabel("Nom Joueur 1:", this);
    player1LineEdit = new QLineEdit(this);
    player2Label = new QLabel("Nom Joueur 2:", this);
    player2LineEdit = new QLineEdit(this);
    modeLabel = new QLabel("Mode:", this);
    modeComboBox = new QComboBox(this);
    modeComboBox->addItem("Normal");
    roundsLabel = new QLabel("Nombre de manches:", this);
    roundsLineEdit = new QLineEdit(this);
    player2HumanRadio = new QRadioButton("Humain", this);
    player2IARadio = new QRadioButton("IA", this);
    allplayersIARadio = new QRadioButton("2 joueurs IA", this);
    allplayersIARadio->setChecked(true);
    player2TypeGroup = new QButtonGroup(this);
    player2TypeGroup->addButton(player2HumanRadio);
    player2TypeGroup->addButton(player2IARadio);
    player2TypeGroup->addButton(allplayersIARadio);

    startButton = new QPushButton("Démarrer la partie", this);

    QVBoxLayout *player2TypeLayout = new QVBoxLayout;
    player2TypeLayout->addWidget(player2HumanRadio);
    player2TypeLayout->addWidget(player2IARadio);
    player2TypeLayout->addWidget(allplayersIARadio);

    QHBoxLayout *player1Layout = new QHBoxLayout;
    player1Layout->addWidget(player1Label);
    player1Layout->addWidget(player1LineEdit);

    QHBoxLayout *player2Layout = new QHBoxLayout;
    player2Layout->addWidget(player2Label);
    player2Layout->addWidget(player2LineEdit);

    QHBoxLayout *modeLayout = new QHBoxLayout;
    modeLayout->addWidget(modeLabel);
    modeLayout->addWidget(modeComboBox);

    QHBoxLayout *roundsLayout = new QHBoxLayout;
    roundsLayout->addWidget(roundsLabel);
    roundsLayout->addWidget(roundsLineEdit);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addLayout(player1Layout);
    mainLayout->addLayout(player2Layout);
    mainLayout->addLayout(player2TypeLayout);
    mainLayout->addLayout(modeLayout);
    mainLayout->addLayout(roundsLayout);
    mainLayout->addWidget(startButton);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(mainLayout);
    setCentralWidget(centralWidget);

    connect(startButton, &QPushButton::clicked, this, &VueParametres::startGame);
}

void VueParametres::startGame() {

    // Récupérer les paramètres
    parametres = getParametres();


    // Appeler la fonction d'initialisation du jeu dans la classe VuePartie
    // en utilisant les paramètres récupérés
    VuePartie* vuePartie = new VuePartie(nullptr,parametres);

    // Afficher la fenêtre de jeu
    vuePartie->show();
    // ferme la fenêtre
    close();

}

