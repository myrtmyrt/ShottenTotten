#ifndef VUEPARAMETRES_H
#define VUEPARAMETRES_H

#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QRadioButton>
#include <QButtonGroup>

struct Parametres {
    QString joueur1;
    QString joueur2;
    QString mode;
    int rounds;
    bool joueur1IA;
    bool joueur2IA;
};

class VueParametres : public QMainWindow
{
    Q_OBJECT

public:
    VueParametres(QWidget *parent = nullptr);

    Parametres getParametres() const;

private slots:
    void startGame();

private:
    QLabel *player1Label;
    QLineEdit *player1LineEdit;
    QLabel *player2Label;
    QLineEdit *player2LineEdit;
    QLabel *modeLabel;
    QComboBox *modeComboBox;
    QLabel *roundsLabel;
    QLineEdit *roundsLineEdit;
    QLabel *player1TypeLabel;
    QLabel *player2TypeLabel;
    QRadioButton *player2HumanRadio;
    QRadioButton *player2IARadio;
    QRadioButton* allplayersIARadio;
    QButtonGroup *player2TypeGroup;

    QPushButton *startButton;

    Parametres parametres;
};

#endif // VUEPARAMETRES_H
