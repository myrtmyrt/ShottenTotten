#ifndef VUEPARTIE_H
#define VUEPARTIE_H

#include "jeu.h"
#include "vueParametres.h"
#include <QMainWindow>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QRadioButton>
#include <QButtonGroup>
#include <QVBoxLayout>

Mode convertQStringToMode(const QString& modeString);


class VuePartie : public QMainWindow
{
    Q_OBJECT

public:
    VuePartie(QWidget *parent = nullptr, Parametres p=Parametres{}):  QMainWindow(parent),param(p){

        // Afficher la fenêtre en plein écran
        showFullScreen();

        // Créer un conteneur pour les QLabel
        QWidget *centralWidget = new QWidget(this);
        QVBoxLayout *layout = new QVBoxLayout(centralWidget);

        // Utiliser les membres de classe pour les QLabel
        shottentotten = new QLabel("Shotten Totten", this);
        shottentotten->setAlignment(Qt::AlignCenter);
        layout->addWidget(shottentotten);

        nbManches = new QLabel(this);
        QString labelText = QString("Nombre de Manches : %1").arg(p.rounds);
        nbManches->setText(labelText);
        nbManches->setAlignment(Qt::AlignCenter);
        layout->addWidget(nbManches);

        QLabel* joueur1BornesLabel = new QLabel("Joueur 1 - Bornes gagnées : 0", this);
        joueur1BornesLabel->setAlignment(Qt::AlignCenter);
        layout->addWidget(joueur1BornesLabel);

        QLabel* joueur2BornesLabel = new QLabel("Joueur 2 - Bornes gagnées : 0", this);
        joueur2BornesLabel->setAlignment(Qt::AlignCenter);
        layout->addWidget(joueur2BornesLabel);

        setCentralWidget(centralWidget);

        // Créez un conteneur de grille pour les cartes bornes
        QGridLayout* gridLayout = new QGridLayout(centralWidget);
        layout->addLayout(gridLayout);

        // Ajoutez les cartes bornes à la grille
        for (int i = 0; i < 9; i++) {
            // Créez un QLabel pour la carte borne
            QLabel* carteBorneLabel = new QLabel("Borne " + QString::number(i + 1), this);
            carteBorneLabel->setFixedSize(130, 60);
            carteBorneLabel->setAlignment(Qt::AlignCenter);

            // Ajoutez un cadre autour de la carte borne
            carteBorneLabel->setFrameShape(QFrame::Box);

            // Ajoutez la carte borne à la grille
            gridLayout->addWidget(carteBorneLabel, 0, i);
        }


        Mode enumMode= convertQStringToMode(param.mode);

        Jeu jeu = Jeu::donneInstance(param.joueur1.toStdString(),param.joueur2IA,param.joueur2.toStdString(),enumMode,param.rounds);
        while(jeu.getJoueur1().getVictoires() < jeu.getNbManchesGagnantes() && jeu.getJoueur2().getVictoires() < jeu.getNbManchesGagnantes()){
            jeu.jouerManche();
        }


        QPushButton* piocherCarteButton = new QPushButton("Piocher une carte", this);
        layout->addWidget(piocherCarteButton);

        /*
     * Affichage du gagnant
     */
        if(jeu.getJoueur1().getVictoires() >= jeu.getNbManchesGagnantes()){
           std::cout<<jeu.getJoueur1().getPseudo()<<" A GAGNE LE JEU !!!!";
        }else{
            std::cout<<jeu.getJoueur2().getPseudo()<<" A GAGNE LE JEU !!!!";
        }

    }

void afficherGagnant(unsigned int numBorne,std::string pseudo);
void afficherGagnantManche(std::string pseudo);
void afficherErreurTactique(){
    QLabel* erreurTactique = new QLabel("Erreur - Vous ne pouvez pas jouer 2 cartes tactiques de plus que l'adversaire !", this);
}
void afficherErreurBorne(){
    QLabel* erreurBorne = new QLabel("Erreur - Vous ne pouvez par revendiquer une borne que vous n'avez pas remplie !", this);
}
void afficherErreurBorneGagnee(){
    QLabel* erreurBorneGagnee = new QLabel("Erreur - Cette borne est déjà gagnée", this);
}

void affichageErreurBorne(){

}

void affichageErreurBorneGagnee(){

}
void afficherBorne(unsigned int numBorne){

}




private slots:

private:
    Parametres param;
    QLabel *shottentotten;
    QLabel *nbManches;



};

#endif // VUEPARTIE_H
