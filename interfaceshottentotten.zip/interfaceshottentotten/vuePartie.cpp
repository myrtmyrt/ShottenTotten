#include "vuePartie.h"
#include "jeu.h"
#include <QVBoxLayout>


Mode convertQStringToMode(const QString& modeString)
{
    if (modeString == "normal")
    {
        return Mode::normal;
    }
    else if (modeString == "tactique")
    {
        return Mode::tactique;
    }
    else if (modeString == "expert")
    {
        return Mode::expert;
    }

    // Valeur par défaut en cas d'erreur ou de couleur non reconnue
    return Mode::normal;
}
